from flask import Flask, flash, redirect, render_template, request, url_for
from flask_bootstrap import Bootstrap
from flask_login import (LoginManager, UserMixin, current_user, login_required,
                         login_user, logout_user)
from flask_mail import Mail, Message
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from werkzeug.security import check_password_hash, generate_password_hash
from wtforms import BooleanField, PasswordField, StringField
from wtforms.validators import Email, InputRequired, Length

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////Users/aarushg/Projects/WebDev/Flask/BookCatalog/database.db'
bootstrap = Bootstrap(app)
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
#login_manager.login_view = 'login'
mail = Mail(app)


app.config.update(
    DEBUG=True,
    # EMAIL SETTINGS
    MAIL_SERVER='smtp.ionos.com',
    MAIL_PORT=587,
    MAIL_USE_SSL=True,
    MAIL_USERNAME='bookcatalog@aarushg.com',
    MAIL_PASSWORD='@B00kcatalog'
)


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(15), unique=True)
    email = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(80))


class Data(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(15))
    title = db.Column(db.String(100))
    author = db.Column(db.String(100))
    dop = db.Column(db.String(100))
    notes = db.Column(db.String())

    def __init__(self, username, title, author, dop, notes):
        self.title = title
        self.username = username
        self.author = author
        self.dop = dop
        self.notes = notes


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class LoginForm(FlaskForm):
    username = StringField('username', validators=[
                           InputRequired(), Length(min=4, max=15)])
    password = PasswordField('password', validators=[
                             InputRequired(), Length(min=8, max=80)])
    remember = BooleanField('remember me')


class RegisterForm(FlaskForm):
    email = StringField('email', validators=[InputRequired(), Email(
        message='Invalid email'), Length(max=50)])
    username = StringField('username', validators=[
                           InputRequired(), Length(min=4, max=15)])
    password = PasswordField('password', validators=[
                             InputRequired(), Length(min=8, max=80)])


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()

    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user:
            if check_password_hash(user.password, form.password.data):
                login_user(user, remember=form.remember.data)
                return redirect(url_for('dashboard'))

        return '<h1>Invalid username or password</h1>'

    return render_template('login.html', form=form)


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = RegisterForm()

    if form.validate_on_submit():
        hashed_password = generate_password_hash(
            form.password.data, method='sha256')
        new_user = User(username=form.username.data,
                        email=form.email.data, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()

        return redirect(url_for('login'))
        # return '<h1>New user has been created!</h1>'

    return render_template('signup.html', form=form)


@app.route('/insert', methods=['POST'])
def insert():

    if request.method == 'POST':

        username = request.form['uName']
        title = request.form['title']
        author = request.form['author']
        dop = request.form['dop']
        notes = request.form['notes']

        my_data = Data(username, title, author, dop, notes)
        db.session.add(my_data)
        db.session.commit()

        flash("Book Inserted Successfully")

        return redirect(url_for('dashboard'))


@app.route('/update', methods=['GET', 'POST'])
def update():

    if request.method == 'POST':
        my_data = Data.query.get(request.form.get('id'))

        my_data.title = request.form['title']
        my_data.author = request.form['author']
        my_data.dop = request.form['dop']
        my_data.notes = request.form['notes']

        db.session.commit()
        flash("Book Updated Successfully")

        return redirect(url_for('dashboard'))


@app.route('/delete/<id>/', methods=['GET', 'POST'])
def delete(id):
    my_data = Data.query.get(id)
    db.session.delete(my_data)
    db.session.commit()
    flash("Book Deleted Successfully")

    return redirect(url_for('dashboard'))


@app.route('/dashboard')
@login_required
def dashboard():

    user_book_data = Data.query.filter_by(username=current_user.username)

    return render_template('dashboard.html', name=current_user.username, books=user_book_data)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
